package com.example.report_ai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
